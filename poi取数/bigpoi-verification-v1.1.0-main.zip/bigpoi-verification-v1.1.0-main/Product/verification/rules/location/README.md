# 空间位置核实规则

本目录包含用于验证POI坐标是否与参考位置一致的规则。

## 规则清单

### 1. 高精度匹配规则

**文件**：`high_precision_match.yaml`

**功能**：坐标差距极小，判定精确匹配

**应用条件**：
- 最小距离 <= 10米

**输出**：
- result: pass
- confidence: 1.0
- distance: 实际距离

### 2. 标准精度匹配规则

**文件**：`standard_precision_match.yaml`

**功能**：坐标在标准误差范围内，判定一致

**应用条件**：
- 10米 < 最小距离 <= 50米

**输出**：
- result: pass
- confidence: 0.90
- distance: 实际距离

### 3. 宽松范围不确定规则

**文件**：`relaxed_range.yaml`

**功能**：坐标偏差较大但仍可接受，需要人工确认

**应用条件**：
- 50米 < 最小距离 <= 100米

**输出**：
- result: uncertain
- confidence: 0.70
- distance: 实际距离

### 4. 超出范围失败规则

**文件**：`out_of_range.yaml`

**功能**：坐标偏差超出可接受范围，判定失败

**应用条件**：
- 最小距离 > 100米

**输出**：
- result: fail
- confidence: 0.2
- distance: 实际距离

## 距离计算方法

使用Haversine公式计算地球表面两点间的距离（以米为单位）：

```
a = sin²(Δlat/2) + cos(lat1) * cos(lat2) * sin²(Δlong/2)
c = 2 * atan2(√a, √(1−a))
d = R * c
```

其中R为地球平均半径6371000米

## 坐标系统标准

- **输入坐标系**：支持WGS84、GCJ02、BD09
- **标准输出坐标系**：GCJ02（国测局坐标系）
- **转换时机**：证据归并与规范化阶段（evidence-collection-merge/scripts/merge_evidence_collection_outputs.py）

## 规则应用顺序

1. 高精度检查（优先级1）
2. 标准精度检查（优先级2）
3. 宽松范围检查（优先级3）
4. 超出范围检查（优先级4）

## 规则修改历史

- 2024-01-15：初始版本创建

